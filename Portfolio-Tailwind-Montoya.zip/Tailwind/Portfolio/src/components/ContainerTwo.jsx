import React from 'react';

export default function ContainerTwo() {
  return (
    <div>
      <div className="h-auto w-full container1bg flex flex-col items-center gap-4 overflow-hidden">
        <h6 className="text-white text-5xl font-bold font-montserrat mt-20 mb-12 translate-y-100 transition-opacity duration-500 transition-transform text-center element spans">
          &nbsp;<span className='container1txtcolor'>Elevate your coding mastery,</span> <br />and drive your business to unprecedented success
        </h6>
        <div className="flex w-full flex-row mb-24 justify-center translate-y-100 transition-opacity duration-500 transition-transform element">
          <div className="w-2/5 max-w-500px p-0 sm:p-4">
            <h1 className="text-white font-montserrat m-0 text-2xl lg:text-3xl font-bold">
              FULL STACK <br /> DEVELOPMENT
            </h1>
            <p className="text-white font-montserrat m-0">
              A Full Stack Developer adept at crafting seamless and immersive user experiences by combining the art of frontend design with the robustness of backend development in web applications.
            </p>
          </div>
          <div className="w-2/5 max-w-500px p-0 sm:p-4">
            <h2 className="text-white font-montserrat m-0 text-2xl lg:text-3xl font-bold">
              SYSTEM ARCHITECTURE <br /> AND OPTIMIZATION
            </h2>
            <p className="text-white font-montserrat m-0">
              A Systems Architect committed to designing and optimizing the backbone of web applications, ensuring their reliability, scalability, and efficiency for seamless user experiences.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
