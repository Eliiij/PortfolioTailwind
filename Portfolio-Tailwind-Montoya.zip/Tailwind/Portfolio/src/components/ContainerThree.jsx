import React from 'react';

export default function ContainerThree() {
  return (
    <div>
      <div className="h-auto w-full container1bg flex items-center flex-col overflow-hidden" id="projects">
        <h3 className="text-white font-montserrat mt-20 mb-12 duration-500 text-center text-5xl font-bold element">My&nbsp;<span className='container1txtcolor'>Projects</span></h3>
        <div className="h-auto w-full flex gap-10 flex-row flex-wrap justify-center items-center mb-24 element">
          <div className="h-96 w-80 m-0  flex items-center justify-center rounded-3xl flex-col container1txt">
            <div className="h-48 w-48 bg-transparent">
              <img className="h-full w-full object-cover rounded-2xl" src="/project-image.png" alt="project1-image" id="image"/>  
            </div>
            <div className="w-auto mx-auto flex justify-center -mt-5 text-white container1bg rounded-t-lg p-2.5 font-montserrat font-semibold">E-commerce Platform</div>
            <div className="mt-5 mb-0 w-4/5 text-white text-center break-all font-montserrat">
              Designed and developed a responsive e-commerce platform with secure payment integration, user authentication, and product management features.
            </div>
          </div>
          <div className="h-96 w-80  flex items-center justify-center rounded-3xl flex-col container1txt">
            <div className="h-48 w-48 bg-transparent">
              <img className="h-full w-full object-cover rounded-2xl" src="/project-image.png" alt="project2-image" id="image"/>  
            </div>
            <div className="w-auto mx-auto flex justify-center -mt-5 text-white container1bg rounded-t-lg p-2.5 font-montserrat font-semibold">Task Management App</div>
            <div className="mt-5 mb-0 w-4/5 text-white text-center break-all font-montserrat">
              Developed a task management application with user-friendly interfaces, real-time collaboration, and progress tracking for efficient project management.
            </div>
          </div>
          <div className="h-96 w-80  flex items-center justify-center rounded-3xl flex-col container1txt">
            <div className="h-48 w-48 bg-transparent">
              <img className="h-full w-full object-cover rounded-2xl" src="/project-image.png" alt="project3-image" id="image"/>  
            </div>
            <div className="w-auto mx-auto flex justify-center -mt-5 text-white container1bg rounded-t-lg p-2.5 font-montserrat font-semibold">Social Media Analytics</div>
            <div className="mt-5 mb-0 w-4/5 text-white text-center break-all font-montserrat">
              Implemented a social media analytics tool that provides insights into user engagement, content performance, and audience demographics.
            </div>
          </div>
          <div className="h-96 w-80  flex items-center justify-center rounded-3xl flex-col container1txt">
            <div className="h-48 w-48 bg-transparent">
              <img className="h-full w-full object-cover rounded-2xl" src="/project-image.png" alt="project4-image" id="image"/>  
            </div>
            <div className="w-auto mx-auto flex justify-center -mt-5 text-white container1bg rounded-t-lg p-2.5 font-montserrat font-semibold">Health and Wellness App</div>
            <div className="mt-5 mb-0 w-4/5 text-white text-center break-all font-montserrat">
              Created a health and wellness application with features for personalized fitness routines, nutrition tracking, and community support.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
