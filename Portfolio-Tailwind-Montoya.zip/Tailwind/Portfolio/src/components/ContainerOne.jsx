import React from 'react';

export default function ContainerOne() {
  return (
    <div>
      <div className="h-screen w-full  flex flex-row items-center overflow-hidden" id="home">
        <div className="w-1/2 h-full flex flex-col mt-96 relative">
            <h1 className="rounded-3xl m-5 ml-40 text-3xl font-montserrat w-fit max-w-367px leading-10 font-normal shadow-box transition-opacity transition-transform translateY-100 mt-1/4 p-1.2rem 1.7rem p-4 mt-1/4 element container1txt">What's up! I am <br /><span className="text-5xl font-bold">Elijah James Montoya</span></h1>
            <h2 className="rounded-3xl m-0 ml-40 text-2xl font-montserrat max-w-367px leading-40 font-normal shadow-box transition-opacity transition-transform translateY-100 mt-2.5rem w-fit max-w-367px p-1.7rem line-h-2rem  p-4 element container1txt">FULL STACK DEVELOPER</h2>
            {/* Add an empty div for positioning */}
            <div style={{ height: '50px' }}></div>
        </div>
        {/* Absolutely position the image to the middle-right and flip horizontally */}
        <div className="avatar-image absolute bottom-0 right-0 top-0 z-1" style={{ transform: 'scaleX(-1)' }}>
          <img className="flex h-auto w-auto" src="/Profile.png" alt="profile"/>
        </div>  
      </div>
    </div>
  )
}
